/**
 * Created by MuTong Yang on 2016/6/14/0014.
 */

//here to write some directives to render the card list, contact list or something else with using in schema form.