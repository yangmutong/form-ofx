(function(){

  "use strict";
  angular.module('ofx.directives',[])
  .directive('ofxCard', ofxCard)
  .controller('ofxCardController', function(){
    var vm = this;
  })

  function ofxCard(){
    return {
        restrict: "E",
        scope: {
            cardData: '=',
            selectItem: '='
        },
        templateUrl: "src/app/template/card.html",
        link: link,
        controllerAs: "vm",
        replace: true,
        controller: "ofxCardController",
        bindToController: true
    };

    function link(scope, element, attrs){
        console.log(scope);
        console.log(attrs);
    }
  }

})();