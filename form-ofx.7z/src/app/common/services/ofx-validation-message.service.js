(function(){
  "use strict";
  angular.module("ofx.services")
  .constant("ofxValidationMessage",{

  })
})();