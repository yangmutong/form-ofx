(function(){
    "use strict";
    angular.module("ofx")
    .controller("ofxHomeController",function($scope){
        console.log("here is home controller");
    });

})();