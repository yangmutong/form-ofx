(function(){
    "use strict";
    angular.module('ofx')
    .controller("ofxToController",function($scope,$state){
        console.log("here is the to page");
    });
})();